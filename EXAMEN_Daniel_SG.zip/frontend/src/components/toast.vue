<script setup>
import { useToastStore } from "@/stores/toastStore.js";
const toast = useToastStore();
</script>

<template>
  <transition name="fade">
    <div v-if="toast.visible" class="app-toast" :class="toast.type">
      {{ toast.message }}
    </div>
  </transition>
</template>

<style scoped>
.app-toast {
  position: fixed;
  top: calc(var(--nav-height, 78px) + 12px);
  left: 50%;
  transform: translateX(-50%);
  padding: 12px 18px;
  border-radius: 10px;
  color: white;
  font-weight: 500;
  box-shadow: 0 10px 25px rgba(0,0,0,.2);
  z-index: 20000;
  max-width: min(520px, calc(100vw - 48px));
  text-align: center;
}

.success { background: #16a34a; }
.error   { background: #dc2626; }
.info    { background: #ff6a00; }
.warning { background: #f59e0b; }

.fade-enter-active,
.fade-leave-active {
  transition: opacity .3s, transform .3s;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: translateX(-50%) translateY(-10px);
}
</style>
